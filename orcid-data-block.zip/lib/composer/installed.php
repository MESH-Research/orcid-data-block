<?php return array(
    'root' => array(
        'pretty_version' => 'dev-master',
        'version' => 'dev-master',
        'type' => 'wordpress-plugin',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'reference' => 'a9010a102f3f3c07df388ca230e97bb11293f3cc',
        'name' => 'mesh-research/orcid-data-block',
        'dev' => false,
    ),
    'versions' => array(
        'mesh-research/orcid-data-block' => array(
            'pretty_version' => 'dev-master',
            'version' => 'dev-master',
            'type' => 'wordpress-plugin',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'reference' => 'a9010a102f3f3c07df388ca230e97bb11293f3cc',
            'dev_requirement' => false,
        ),
    ),
);
